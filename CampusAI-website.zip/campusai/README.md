# CampusAI — College Event Demo

A polished, responsive, front-end-only CampusAI prototype inspired by the supplied reference board.

## Features
- Futuristic responsive landing page
- AI command center demo
- Personalized study planner
- Notes → summary → important questions → quiz
- Placement roadmaps for 4 roles
- Daily goals with LocalStorage persistence
- Smooth reveal/hover animations
- No backend or API key required

## Run locally
Open `index.html` in a browser, or use VS Code Live Server.

## Deploy for free
### GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `styles.css`, `app.js`, and `README.md`.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/root`.
5. Save and wait for the public URL.

### Vercel
Import the GitHub repository into Vercel. No build command is needed; the site is static.

## Important
The AI interactions are intentionally simulated in the browser so the project can be demonstrated without paid APIs. For a production version, connect the command center, notes analyzer and planner to a secure backend/API.
